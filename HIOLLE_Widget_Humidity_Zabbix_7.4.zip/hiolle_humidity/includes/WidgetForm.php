<?php declare(strict_types=1);
namespace Modules\HiolleHumidity\Includes;
require_once __DIR__.'/TemplateField.php';
use Zabbix\Widgets\Fields\CWidgetFieldColor;
use Zabbix\Widgets\Fields\CWidgetFieldIntegerBox;
use Zabbix\Widgets\Fields\CWidgetFieldMultiSelectGroup;
class WidgetForm extends \Zabbix\Widgets\CWidgetForm {
    public function addFields(): self {
        return $this
            ->addField(new CWidgetFieldMultiSelectGroup('groupids', _('Groupes d’hôtes')))
            ->addField(new CWidgetFieldMultiSelectTemplate('templateids', _('Modèles d’éléments')))
            ->addField(new \Zabbix\Widgets\Fields\CWidgetFieldMultiSelectItem('itemid', _('Éléments humidité')))
            ->addField((new \Zabbix\Widgets\Fields\CWidgetFieldCheckBox('demo', _('Simulation si aucun élément sélectionné')))->setDefault(1))
            ->addField((new CWidgetFieldIntegerBox('demo_value', _('Humidité simulée (%)'), 0, 100))->setDefault(55))
            ->addField((new CWidgetFieldIntegerBox('warning', _('Orange dès (%)'), 0, 100))->setDefault(60))
            ->addField((new CWidgetFieldIntegerBox('critical', _('Rouge dès (%)'), 0, 100))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('value_size', _('Taille des chiffres (px)'), 12, 160))->setDefault(64))
            ->addField((new CWidgetFieldIntegerBox('name_size', _('Taille du nom (px)'), 8, 40))->setDefault(12))
            ->addField((new \Zabbix\Widgets\Fields\CWidgetFieldCheckBox('name_bold', _('Nom en gras')))->setDefault(0))
            ->addField((new \Zabbix\Widgets\Fields\CWidgetFieldCheckBox('center_name', _('Centrer le nom')))->setDefault(1))
            ->addField((new CWidgetFieldColor('ok_color', _('Couleur normale')))->setDefault('46CF80'))
            ->addField((new CWidgetFieldColor('warning_color', _('Couleur attention')))->setDefault('FFB742'))
            ->addField((new CWidgetFieldColor('critical_color', _('Couleur critique')))->setDefault('FF5264'));
    }
}
