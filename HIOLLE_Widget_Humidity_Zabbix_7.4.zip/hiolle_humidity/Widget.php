<?php declare(strict_types=1);
namespace Modules\HiolleHumidity;
class Widget extends \Zabbix\Core\CWidget {}
