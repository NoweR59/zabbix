<?php declare(strict_types=1);
namespace Modules\HiolleHumidity\Actions;
class WidgetView extends \CControllerDashboardWidgetView {
    protected function doAction(): void {
        $warning = max(0, min(100, (int) ($this->fields_values['warning'] ?? 60)));
        $critical = max($warning, min(100, (int) ($this->fields_values['critical'] ?? 80)));
        $ids = array_values(array_filter(array_map('strval', (array) ($this->fields_values['itemid'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
        $rows = [];
        if ($ids) {
            $params = ['itemids' => $ids, 'output' => ['name', 'lastvalue', 'lastclock', 'value_type', 'status', 'state'], 'selectHosts' => ['host', 'name']];
            $groups = array_values(array_filter(array_map('strval', (array) ($this->fields_values['groupids'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
            $templates = array_values(array_filter(array_map('strval', (array) ($this->fields_values['templateids'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
            if ($groups) { $params['groupids'] = $groups; }
            if ($templates) { $params['templateids'] = $templates; }
            foreach (\API::Item()->get($params) as $item) {
                $value = null;
                if (in_array((int) $item['value_type'], [0, 3], true) && (int) $item['status'] === 0 && (int) $item['state'] === 0
                        && (int) $item['lastclock'] >= time() - 3600 && is_numeric($item['lastvalue'])) { $value = (float) $item['lastvalue']; }
                $host = $item['hosts'][0] ?? [];
                $host_name = $host['name'] ?? ($host['host'] ?? $item['name']);
                $site_name = trim((string) preg_replace('/^\s*H%\s*[-–—:]?\s*/u', '', $host_name));
                $rows[] = ['name' => 'H% - '.($site_name !== '' ? $site_name : $host_name), 'value' => $value, 'state' => $value === null ? 'unknown' : ($value >= $critical ? 'critical' : ($value >= $warning ? 'warning' : 'ok'))];
            }
        }
        elseif (($this->fields_values['demo'] ?? 1)) {
            $demo = (float) ($this->fields_values['demo_value'] ?? 55);
            $rows[] = ['name' => 'Humidité simulée', 'value' => $demo, 'state' => $demo >= $critical ? 'critical' : ($demo >= $warning ? 'warning' : 'ok')];
        }
        $clean = static function ($value, string $fallback): string { $value = preg_replace('/[^0-9A-Fa-f]/', '', (string) $value); return '#'.(strlen($value) === 6 ? $value : $fallback); };
        $colors = ['ok' => $clean($this->fields_values['ok_color'] ?? '', '46CF80'), 'warning' => $clean($this->fields_values['warning_color'] ?? '', 'FFB742'), 'critical' => $clean($this->fields_values['critical_color'] ?? '', 'FF5264'), 'unknown' => '#93A7B7'];
        $this->setResponse(new \CControllerResponseData(['name' => $this->getInput('name', $this->widget->getName()), 'rows' => $rows, 'colors' => $colors, 'size' => max(12, min(160, (int) ($this->fields_values['value_size'] ?? 64))), 'name_size' => max(8, min(40, (int) ($this->fields_values['name_size'] ?? 12))), 'name_bold' => !empty($this->fields_values['name_bold']), 'center_name' => !empty($this->fields_values['center_name'])]));
    }
}
