<?php declare(strict_types=1);
$body = (new CDiv())->addClass('hiolle-humidity-list');
foreach ($data['rows'] as $row) {
    $value = $row['value'] === null ? '—' : number_format($row['value'], 0, ',', ' ').'%';
    $item = (new CDiv([(new CDiv($row['name']))->addClass('hiolle-humidity-name'.($data['name_bold'] ? ' hiolle-humidity-name-bold' : '')),(new CDiv($value))->addClass('hiolle-humidity-value hiolle-humidity-'.$row['state'])]))->addClass('hiolle-humidity-item'.($data['center_name'] ? ' hiolle-humidity-center-name' : ''))->setAttribute('style', '--humidity-size:'.$data['size'].'px;--humidity-name-size:'.$data['name_size'].'px;--humidity-color:'.$data['colors'][$row['state']].';');
    $body->addItem($item);
}
(new CWidgetView($data))->addItem($body)->show();
