<?php declare(strict_types=1);

namespace Modules\HiolleProblemList;

use Zabbix\Core\CWidget;

class Widget extends CWidget {
}
