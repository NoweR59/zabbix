<?php declare(strict_types=1);

namespace Modules\HiolleProblemList\Actions;

use API;
use CControllerDashboardWidgetView;
use CControllerResponseData;
use Modules\HiolleProblemList\Includes\SsaCli;
use Modules\HiolleProblemList\Includes\StorCli;
require_once dirname(__DIR__).'/includes/SsaCli.php';
require_once dirname(__DIR__).'/includes/StorCli.php';

/**
 * Read-only dashboard controller. Uses the current Zabbix user's permissions.
 * No API token, external HTTP request, background daemon or extra database tables.
 */
class WidgetView extends CControllerDashboardWidgetView {

    private const MAX_HOSTS = 100;
    private const DATA_MAX_AGE = 3600;
    private const LIVE_MAX_AGE = 180;  // Fresh data used as a fallback for active agents.

    protected function doAction(): void {
        $selected_ids = array_slice(array_values(array_unique(array_filter(
            array_map('strval', (array) ($this->fields_values['hostids'] ?? [])),
            static fn(string $id): bool => ctype_digit($id) && $id !== '0'
        ))), 0, self::MAX_HOSTS);

        // Automatic mode: when no hosts are selected, inspect all monitored hosts
        // and keep only those whose CPU/RAM/DISK values cross the thresholds.
        if (!$selected_ids) {
            $auto_hosts = API::Host()->get([
                'output' => ['hostid'],
                'groupids' => $this->fields_values['groupids'] ?: null,
                'filter' => ['status' => 0],
                'limit' => self::MAX_HOSTS
            ]);
            $selected_ids = array_map('strval', array_column($auto_hosts, 'hostid'));
        }

        $thresholds = [];
        foreach (['cpu', 'ram', 'disk'] as $name) {
            $warning = max(0, min(100, (int) ($this->fields_values[$name.'_warning'] ?? 80)));
            $critical = max(0, min(100, (int) ($this->fields_values[$name.'_critical'] ?? 90)));
            $thresholds[$name] = ['warning' => $warning, 'critical' => $critical];
        }

        $font_size = (int) ($this->fields_values['font_size'] ?? 9);
        $font_size = max(6, min(16, $font_size));
        $windows_logo_size = (int) ($this->fields_values['windows_logo_size'] ?? $this->fields_values['logo_size'] ?? 13);
        $linux_logo_size = (int) ($this->fields_values['linux_logo_size'] ?? $this->fields_values['logo_size'] ?? 13);
        $windows_logo_size = max(7, min(20, $windows_logo_size));
        $linux_logo_size = max(7, min(20, $linux_logo_size));
        $card_height = (int) ($this->fields_values['card_height'] ?? 36);
        $metric_size = (int) ($this->fields_values['metric_size'] ?? 22);
        $card_height = max(30, min(80, $card_height));
        $metric_size = max(16, min(40, $metric_size));
        $logo_name_gap = (int) ($this->fields_values['logo_name_gap'] ?? 2);
        $logo_name_gap = max(0, min(20, $logo_name_gap));
        $ping_size = (int) ($this->fields_values['ping_size'] ?? 2);
        $ping_size = max(1, min(8, $ping_size));
        $ok_color = strtoupper((string) ($this->fields_values['ok_color'] ?? '46CF80'));
        $warning_color = strtoupper((string) ($this->fields_values['warning_color'] ?? 'FFB742'));
        $critical_color = strtoupper((string) ($this->fields_values['critical_color'] ?? 'FF5264'));
        $style = [
            'font_size' => $font_size,
            'windows_logo_size' => $windows_logo_size,
            'linux_logo_size' => $linux_logo_size,
            'card_height' => $card_height,
            'metric_size' => $metric_size,
            'logo_name_gap' => $logo_name_gap,
            'ping_size' => $ping_size,
            'ok_color' => preg_match('/^[0-9A-F]{6}$/', $ok_color) ? $ok_color : '46CF80',
            'warning_color' => preg_match('/^[0-9A-F]{6}$/', $warning_color) ? $warning_color : 'FFB742',
            'critical_color' => preg_match('/^[0-9A-F]{6}$/', $critical_color) ? $critical_color : 'FF5264',
            'names_bold' => !empty($this->fields_values['names_bold']),
            'names_italic' => !empty($this->fields_values['names_italic']),
            'show_logo' => !array_key_exists('show_logo', $this->fields_values) || !empty($this->fields_values['show_logo']),
            'center_logo' => !empty($this->fields_values['center_logo'])
                || !empty($this->fields_values['center_identity']),
            'center_name' => !empty($this->fields_values['center_name'])
                || !empty($this->fields_values['center_identity']),
            'center_metrics' => !empty($this->fields_values['center_metrics'])
        ];

        $cards = [];
        if ($selected_ids) {
            $hosts = API::Host()->get([
                'output' => ['hostid', 'host', 'name', 'status'],
                'hostids' => $selected_ids,
                'groupids' => $this->fields_values['groupids'] ?: null,
                'selectInterfaces' => ['type', 'available'],
                'selectInventory' => ['os'],
                'selectParentTemplates' => ['name']
            ]);

            // Query only common relevant metrics, avoiding scans of full item histories.
            $visible_ids = array_column($hosts, 'hostid');
            $by_host = [];
            if ($visible_ids) {
                $items = API::Item()->get([
                    'output' => ['itemid', 'hostid', 'key_', 'lastvalue', 'lastclock', 'value_type', 'status', 'state'],
                    'hostids' => $visible_ids,
                    'search' => ['key_' => ['system.cpu.util', 'vm.memory.', 'system.uname', 'icmpping', 'hiolle.raid.ssacli', 'hiolle.raid.storcli']],
                    'searchByAny' => true
                ]);
                foreach ($items as $item) {
                    $by_host[(string) $item['hostid']][(string) $item['key_']] = $item;
                }

                // Supports the discovered vfs.fs.size and vfs.fs.dependent.size percentage keys.
                $disks = API::Item()->get([
                    'output' => ['itemid', 'hostid', 'key_', 'lastvalue', 'lastclock', 'value_type', 'status', 'state'],
                    'hostids' => $visible_ids,
                    'search' => ['key_' => 'vfs.fs.']
                ]);
                foreach ($disks as $item) {
                    if (preg_match('~^vfs\.fs\.(?:dependent\.)?size\[([^,]+),(pused|pfree)\]$~i', (string) $item['key_'])) {
                        $by_host[(string) $item['hostid']][(string) $item['key_']] = $item;
                    }
                }


            }

            $hosts_by_id = [];
            foreach ($hosts as $host) {
                $hosts_by_id[(string) $host['hostid']] = $host;
            }

            // Preserve the selection order, even when the API returns a different order.
            foreach ($selected_ids as $hostid) {
                if (!isset($hosts_by_id[$hostid])) {
                    continue; // Respect user host permissions.
                }

                $host = $hosts_by_id[$hostid];
                $host_items = $by_host[$hostid] ?? [];
                $cpu = $this->chooseMetric($host_items, ['system.cpu.util', 'system.cpu.util[,used]']);
                if ($cpu['value'] === null) {
                    $idle = $this->chooseMetric($host_items, ['system.cpu.util[,idle]', 'system.cpu.util[,idle,avg1]']);
                    if ($idle['value'] !== null) {
                        $cpu = ['value' => round(100 - $idle['value'], 1), 'clock' => $idle['clock']];
                    }
                }
                $ram = $this->chooseMetric($host_items, ['vm.memory.util', 'vm.memory.utilization', 'vm.memory.size[pused]']);
                if ($ram['value'] === null) {
                    $available = $this->chooseMetric($host_items, ['vm.memory.size[pavailable]']);
                    if ($available['value'] !== null) {
                        $ram = ['value' => round(100 - $available['value'], 1), 'clock' => $available['clock']];
                    }
                    else {
                        $total = $this->validValue($host_items['vm.memory.size[total]'] ?? null, false);
                        $free = $this->validValue($host_items['vm.memory.size[available]'] ?? null, false);
                        if ($total !== null && $free !== null && $total['value'] > 0 && $free['value'] <= $total['value']) {
                            $ram = ['value' => round(100 * (1 - $free['value'] / $total['value']), 1),
                                'clock' => min($total['clock'], $free['clock'])];
                        }
                    }
                }
                $os = $this->getOS($host, $host_items);
                $disk = $this->getDisk($host_items, $os);
                $agent = $this->getPingState($host, $host_items);
                $extra = $this->raidProblems($host_items);
                if ($agent['state'] === 'critical') { $extra[] = ['PING', 'DOWN', 'critical']; }

                $levels = [
                    'cpu' => $this->getLevel($cpu['value'], $thresholds['cpu']),
                    'ram' => $this->getLevel($ram['value'], $thresholds['ram']),
                    'disk' => $this->getLevel($disk['value'], $thresholds['disk'])
                ];
                $priority = ['ok' => 0, 'unknown' => 1, 'warning' => 2, 'critical' => 3];
                $overall = 'ok';
                foreach (array_merge(array_values($levels), [$agent['state']]) as $level) {
                    if (($priority[$level] ?? 1) > $priority[$overall]) {
                        $overall = $level;
                    }
                }

                $cards[] = [
                    'hostid' => (string) $host['hostid'],
                    'name' => (string) ($host['name'] ?: $host['host']),
                    'os' => $os,
                    'overall' => $overall,
                    'cpu' => ['value' => $cpu['value'], 'level' => $levels['cpu']],
                    'ram' => ['value' => $ram['value'], 'level' => $levels['ram']],
                    'disk' => ['value' => $disk['value'], 'level' => $levels['disk'], 'volume' => $disk['volume'] ?? null],
                    'agent' => $agent, 'extra' => $extra
                ];
            }
        }

        if (!empty($this->fields_values['demo'])) {
            $cards = [];
            foreach ([
                ['HV-PROUVY-01', 'windows', 96, 74, 41, 'critical', [['TEMP', '78°C', 'critical']]],
                ['HV-VALENCIENNES-01', 'hyperv', 62, 94, 88, 'critical', [['RAID', '3/4', 'critical'], ['NET', '92%', 'warning']]],
                ['LINUX-REIMS-01', 'linux', 28, 67, 93, 'critical', [['PING', 'DOWN', 'critical']]],
                ['SRV-FAMECK-01', 'windows', 91, 52, 44, 'critical', [['SERVICE', 'STOP', 'critical']]],
                ['SRV-OSNY-01', 'linux', 44, 38, 58, 'warning', [['UPTIME', '112j', 'warning']]],
                ['HV-GAILLON-01', 'hyperv', 73, 86, 61, 'warning', [['TEMP', '66°C', 'warning'], ['RAID', 'OK', 'warning']]],
                ['SRV-ISTRES-01', 'windows', 22, 31, 92, 'critical', [['DISK', '92%', 'critical'], ['PING', 'DOWN', 'critical']]],
                ['SRV-MAROC-01', 'linux', 96, 91, 96, 'critical', [['SERVICE', 'STOP', 'critical'], ['NET', '98%', 'critical']]]
            ] as [$name, $os, $cpu, $ram, $disk, $overall, $extra]) {
                $cards[] = [
                    'hostid' => 'demo-'.$name, 'name' => $name, 'os' => $os, 'overall' => $overall,
                    'cpu' => ['value' => $cpu, 'level' => $this->getLevel((float) $cpu, $thresholds['cpu'])],
                    'ram' => ['value' => $ram, 'level' => $this->getLevel((float) $ram, $thresholds['ram'])],
                    'disk' => ['value' => $disk, 'level' => $this->getLevel((float) $disk, $thresholds['disk']), 'volume' => 'C:'],
                    'agent' => ['state' => 'ok', 'label' => 'Simulation'], 'extra' => $extra
                ];
            }
        }

        if (empty($this->fields_values['demo']) && $selected_ids) {
            $events = API::Trigger()->get(['hostids' => $selected_ids, 'output' => ['description', 'priority'],
                'filter' => ['value' => 1], 'monitored' => true, 'skipDependent' => true,
                'selectHosts' => ['hostid'], 'expandDescription' => true]);
            foreach ($events as $event) {
                $label = null;
                foreach (['TEMP' => '~température|temperature~iu', 'SERVICE' => '~service~iu',
                    'UPTIME' => '~uptime~iu', 'NET' => '~bandwidth|utilization.*interface|interface.*utilization|bande passante~iu'] as $category => $pattern) {
                    if (preg_match($pattern, $event['description'])) { $label = $category; break; }
                }
                if ($label === null) { continue; }
                foreach ($cards as &$card) {
                    if (in_array($card['hostid'], array_column($event['hosts'], 'hostid'))) {
                        $card['extra'][] = [$label, $event['description'], (int) $event['priority'] >= 4 ? 'critical' : 'warning'];
                    }
                }
                unset($card);
            }
        }
        foreach ($cards as &$card) {
            $levels = array_merge(array_column([$card['cpu'], $card['ram'], $card['disk']], 'level'), array_column($card['extra'] ?? [], 2));
            $card['overall'] = in_array('critical', $levels, true) ? 'critical' : (in_array('warning', $levels, true) ? 'warning' : 'ok');
        }
        unset($card);
        $priority = ['critical' => 3, 'warning' => 2, 'unknown' => 1, 'ok' => 0];
        usort($cards, static function (array $a, array $b) use ($priority): int {
            $overall = ($priority[$b['overall']] ?? 0) <=> ($priority[$a['overall']] ?? 0);
            if ($overall !== 0) { return $overall; }
            $count = static function (array $card): int {
                $total = 0;
                foreach (['cpu', 'ram', 'disk'] as $metric) {
                    $total += in_array($card[$metric]['level'] ?? 'unknown', ['warning', 'critical'], true) ? 1 : 0;
                }
                return $total + count($card['extra'] ?? []);
            };
            return $count($b) <=> $count($a);
        });

        $this->setResponse(new CControllerResponseData([
            'name' => $this->getInput('name', $this->widget->getName()),
            'cards' => $cards,
            'style' => $style,
            'selected_count' => count($selected_ids),
            'user' => ['debug_mode' => $this->getDebugMode()]
        ]));
    }

    private function raidProblems(array $items): array {
        $sources = [];
        foreach (['hiolle.raid.ssacli', 'hiolle.raid.storcli'] as $key) {
            $item = $items[$key] ?? null;
            if (!$item || (int) $item['status'] !== 0 || (int) $item['state'] !== 0 || (int) $item['lastclock'] < time() - self::DATA_MAX_AGE) { continue; }
            $sources[$key] = $item;
        }
        uasort($sources, static fn($a, $b) => (int) $b['lastclock'] <=> (int) $a['lastclock']);
        foreach ($sources as $key => $item) {
            $disks = $key === 'hiolle.raid.ssacli' ? (SsaCli::parse($item['lastvalue'])['disks'] ?? []) : (StorCli::parse($item['lastvalue']) ?? []);
            if (!$disks) { continue; }
            $problems = [];
            foreach ($disks as $disk) {
                if (in_array($disk['state'], ['failed', 'predictive'], true)) {
                    $problems[] = ['RAID', ($disk['slot'] ?? '?').' '.($disk['state'] === 'failed' ? 'HS' : 'dégradé'), $disk['state'] === 'failed' ? 'critical' : 'warning'];
                }
            }
            return $problems;
        }
        return [];
    }

    private function validValue(?array $item, bool $percentage = true): ?array {
        if ($item === null || (int) ($item['status'] ?? 1) !== 0 || (int) ($item['state'] ?? 0) !== 0) {
            return null;
        }
        $clock = (int) ($item['lastclock'] ?? 0);
        if ($clock <= 0 || $clock < time() - self::DATA_MAX_AGE || !is_numeric($item['lastvalue'] ?? null)) {
            return null;
        }
        $number = (float) $item['lastvalue'];
        if (!is_finite($number) || $number < 0 || ($percentage && $number > 100)) {
            return null;
        }
        return ['value' => round($number, 1), 'clock' => $clock];
    }

    private function chooseMetric(array $items, array $keys): array {
        foreach ($keys as $key) {
            $metric = $this->validValue($items[$key] ?? null);
            if ($metric !== null) {
                return $metric;
            }
        }
        return ['value' => null, 'clock' => 0];
    }

    private function getDisk(array $items, string $os): array {
        $candidates = [];
        foreach ($items as $key => $item) {
            if (!preg_match('~^vfs\.fs\.(?:dependent\.)?size\[([^,]+),(pused|pfree)\]$~i', $key, $matches)) {
                continue;
            }
            $metric = $this->validValue($item);
            if ($metric === null) {
                continue;
            }
            $volume = trim($matches[1], "\"'");
            if ($matches[2] === 'pfree') {
                $metric['value'] = round(100 - $metric['value'], 1);
            }
            $metric['volume'] = $volume;
            $candidates[] = $metric;
        }
        usort($candidates, static fn(array $a, array $b): int => $b['value'] <=> $a['value']);
        return $candidates[0] ?? ['value' => null, 'clock' => 0, 'volume' => null];
    }

    private function getOS(array $host, array $items): string {
        $parts = [
            (string) ($host['inventory']['os'] ?? ''),
            (string) ($host['host'] ?? ''),
            (string) ($host['name'] ?? '')
        ];
        $uname = $items['system.uname'] ?? null;
        if ($uname !== null && (int) ($uname['lastclock'] ?? 0) > 0) {
            $parts[] = (string) ($uname['lastvalue'] ?? '');
        }
        foreach ($host['parentTemplates'] ?? [] as $template) {
            $parts[] = (string) ($template['name'] ?? '');
        }
        $text = strtolower(implode(' ', $parts));
        if (str_contains($text, 'windows')) {
            return 'windows';
        }
        if (preg_match('~hyper[ -]?v|hyperviseur|hypervisor~', $text)) {
            return 'hyperv';
        }
        if (str_contains($text, 'linux') || str_contains($text, 'ubuntu') || str_contains($text, 'debian')) {
            return 'linux';
        }
        return 'unknown';
    }

    private function getPingState(array $host, array $items): array {
        if ((int) $host['status'] !== 0) {
            return ['state' => 'unknown', 'label' => 'Hôte désactivé'];
        }
        // Only the default host-target ping: parameterized keys may probe another destination.
        $ping = $this->validValue($items['icmpping'] ?? $items['icmpping[]'] ?? null);
        if ($ping === null || !in_array($ping['value'], [0.0, 1.0], true)) {
            return ['state' => 'unknown', 'label' => 'Ping ICMP absent, périmé ou non pris en charge'];
        }
        return $ping['value'] === 1.0
            ? ['state' => 'ok', 'label' => 'Ping ICMP : réponse reçue']
            : ['state' => 'critical', 'label' => 'Ping ICMP : aucune réponse'];
    }

    private function getLevel(?float $value, array $threshold): string {
        if ($value === null) {
            return 'unknown';
        }
        if ($value >= $threshold['critical']) {
            return 'critical';
        }
        if ($value >= $threshold['warning']) {
            return 'warning';
        }
        return 'ok';
    }
}
