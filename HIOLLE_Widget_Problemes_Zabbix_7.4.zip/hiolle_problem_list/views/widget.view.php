<?php declare(strict_types=1);

/** @var array $data */

$tag = static function(string $name, string $class, $children = ''): CTag {
    return (new CTag($name, true, $children))->addClass($class);
};

$rows = [];
$problem_total = 0;
$critical_total = 0;
$warning_total = 0;
$hosts_total = 0;
foreach ($data['cards'] as $card) {
    $problems = [];
    foreach (['cpu' => 'CPU', 'ram' => 'RAM', 'disk' => 'DISK'] as $key => $label) {
        $metric = $card[$key] ?? [];
        if (in_array($metric['level'] ?? 'unknown', ['warning', 'critical'], true)) {
            $level = $metric['level'];
            $value = $metric['value'] === null ? '—' : number_format((float) $metric['value'], 0, ',', ' ').'%';
            $problems[] = $tag('span', 'hiolle-problem-pill hiolle-problem-pill-'.$level, [
                $tag('span', 'hiolle-problem-pill-label', $label),
                $tag('span', 'hiolle-problem-pill-value', $value)
            ]);
            $problem_total++;
            $level === 'critical' ? $critical_total++ : $warning_total++;
        }
    }
    foreach (($card['extra'] ?? []) as [$label, $value, $level]) {
        $problems[] = $tag('span', 'hiolle-problem-pill hiolle-problem-pill-'.$level, [
            $tag('span', 'hiolle-problem-pill-label', $label),
            $tag('span', 'hiolle-problem-pill-value', $value)
        ]);
        $problem_total++;
        $level === 'critical' ? $critical_total++ : $warning_total++;
    }
    if (!$problems) {
        continue;
    }
    $os = $card['os'] ?? 'unknown';
    if ($os === 'windows') {
        $logo = $tag('span', 'hiolle-problem-logo hiolle-problem-logo-windows', [
            $tag('i', 'hiolle-problem-win-tile'), $tag('i', 'hiolle-problem-win-tile'),
            $tag('i', 'hiolle-problem-win-tile'), $tag('i', 'hiolle-problem-win-tile')
        ]);
    }
    elseif ($os === 'linux') {
        $logo = $tag('span', 'hiolle-problem-logo hiolle-problem-logo-linux', '🐧');
    }
    elseif ($os === 'hyperv') {
        $logo = $tag('span', 'hiolle-problem-logo hiolle-problem-logo-hyperv', 'H');
    }
    else {
        $logo = $tag('span', 'hiolle-problem-logo hiolle-problem-logo-unknown', '▣');
    }
    $hosts_total++;
    $rows[] = $tag('div', 'hiolle-problem-row hiolle-problem-row-'.$card['overall'], [
        $tag('div', 'hiolle-problem-host', [$logo, $tag('span', 'hiolle-problem-host-name', $card['name'])]),
        $tag('div', 'hiolle-problem-metrics', $problems)
    ]);
}

$header = $tag('div', 'hiolle-problem-header', [
    $tag('div', 'hiolle-problem-heading', [$tag('span', 'hiolle-problem-title', 'PROBLÈMES'), $tag('span', 'hiolle-problem-subtitle', $hosts_total.' hôte'.($hosts_total > 1 ? 's' : ''))]),
    $tag('div', 'hiolle-problem-summary', [
        $tag('span', 'hiolle-problem-summary-critical', $critical_total.' critique'.($critical_total > 1 ? 's' : '')),
        $tag('span', 'hiolle-problem-summary-warning', $warning_total.' attention'),
        $tag('span', 'hiolle-problem-count', (string) $problem_total)
    ])
]);

if (!$rows) {
    $rows[] = $tag('div', 'hiolle-problem-empty', 'Aucun problème CPU, RAM ou DISK détecté.');
}

$content = $tag('div', 'hiolle-problem-list', array_merge([$header], $rows));

(new CWidgetView($data))
    ->addItem($content)
    ->show();
