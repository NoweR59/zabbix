<?php declare(strict_types=1);

/**
 * @var CView $this
 * @var array $data
 *
 * HTML is built with Zabbix CTag classes so host names are escaped.
 */

$tag = static function(string $name, string $class, $children = ''): CTag {
    return (new CTag($name, true, $children))->addClass($class);
};

$ring = static function(string $label, array $metric, ?string $subtitle = null) use ($tag): CTag {
    $value = $metric['value'];
    $level = $metric['level'];
    $percent = $value === null ? 0 : max(0, min(100, (float) $value));
    $label_value = $value === null ? '—' : number_format((float) $value, 0, ',', ' ').'%';

    $face = $tag('div', 'hiolle-gauge-inner', [
        $tag('span', 'hiolle-gauge-value', $label_value)
    ]);
    $circle = $tag('div', 'hiolle-gauge hiolle-level-'.$level, $face);
    $circle->setAttribute('style', '--hiolle-pct:'.number_format($percent, 2, '.', '').'%');
    $circle->setAttribute('title', $label.': '.$label_value.($subtitle ? ' ('.$subtitle.')' : ''));

    return $tag('div', 'hiolle-metric', [
        $circle,
        $tag('div', 'hiolle-metric-label', $label)
    ]);
};

$cards = [];
foreach ($data['cards'] as $card) {
    $os = $card['os'];
    if ($os === 'windows') {
        $logo = $tag('span', 'hiolle-windows-logo', [
            $tag('i', 'hiolle-win-tile'), $tag('i', 'hiolle-win-tile'),
            $tag('i', 'hiolle-win-tile'), $tag('i', 'hiolle-win-tile')
        ]);
        $os_name = 'Windows';
    }
    elseif ($os === 'linux') {
        $logo = $tag('span', 'hiolle-linux-logo', '🐧');
        $os_name = 'Linux';
    }
    else {
        $logo = $tag('span', 'hiolle-generic-logo', '▣');
        $os_name = 'Système non identifié';
    }

    $overall = $card['overall'];
    $labels = [
        'ok' => 'Normal',
        'warning' => 'Attention',
        'critical' => 'Critique',
        'unknown' => 'À vérifier'
    ];

    $status = $tag('div', 'hiolle-status hiolle-level-'.$card['agent']['state'], [
        $tag('span', 'hiolle-status-dot'),
        $tag('span', 'hiolle-status-text', $card['agent']['label'])
    ]);
    $status->setAttribute('title', $card['agent']['label']);

    $header = $tag('div', 'hiolle-server-header', [
        $logo,
        $tag('div', 'hiolle-server-identity', [
            $tag('div', 'hiolle-server-name', $card['name']),
            $tag('div', 'hiolle-server-os', $os_name)
        ])
    ]);

    $cards[] = $tag('div', 'hiolle-server-card hiolle-border-'.$overall, [
        $header,
        $status,
        $ring('CPU', $card['cpu']),
        $ring('RAM', $card['ram']),
        $ring('DISK', $card['disk'], $card['disk']['volume'] ?? null)
    ]);
}

if (!$cards) {
    $cards[] = $tag('div', 'hiolle-empty',
        'Sélectionnez un ou plusieurs hôtes dans la configuration du widget. Si vous en avez déjà choisi, vérifiez les droits de lecture.'
    );
}

$grid = $tag('div', 'hiolle-dashboard-grid', $cards);

(new CWidgetView($data))
    ->addItem($grid)
    ->show();
