<?php declare(strict_types=1);

/**
 * @var CView $this
 * @var array $data
 *
 * HTML is built with Zabbix CTag classes so host names are escaped.
 */

$tag = static function(string $name, string $class, $children = ''): CTag {
    return (new CTag($name, true, $children))->addClass($class);
};

$ring = static function(string $label, array $metric, ?string $subtitle = null) use ($tag): CTag {
    $value = $metric['value'];
    $level = $metric['level'];
    $percent = $value === null ? 0 : max(0, min(100, (float) $value));
    $label_value = $value === null ? '—' : number_format((float) $value, 0, ',', ' ').'%';

    $face = $tag('div', 'hiolle-gauge-inner', [
        $tag('span', 'hiolle-gauge-value', $label_value)
    ]);
    $circle = $tag('div', 'hiolle-gauge hiolle-level-'.$level, $face);
    $circle->setAttribute('style', '--hiolle-pct:'.number_format($percent, 2, '.', '').'%');
    $circle->setAttribute('title', $label.': '.$label_value.($subtitle ? ' ('.$subtitle.')' : ''));

    return $tag('div', 'hiolle-metric', [
        $circle,
        $tag('div', 'hiolle-metric-label', $label)
    ]);
};

$cards = [];
$style = $data['style'] ?? [
    'font_size' => 9,
    'windows_logo_size' => 13,
    'linux_logo_size' => 13,
    'card_height' => 36,
    'metric_size' => 22,
    'logo_name_gap' => 2,
    'ping_size' => 2,
    'ok_color' => '46CF80',
    'warning_color' => 'FFB742',
    'critical_color' => 'FF5264',
    'names_bold' => false,
    'names_italic' => false,
    'show_logo' => true,
    'center_logo' => false,
    'center_name' => false,
    'center_metrics' => false
];
$grid_classes = 'hiolle-dashboard-grid hiolle-font-size-'.$style['font_size'];
$grid_classes .= !empty($style['names_bold']) ? ' hiolle-names-bold' : '';
$grid_classes .= !empty($style['names_italic']) ? ' hiolle-names-italic' : '';
$grid_classes .= empty($style['show_logo']) ? ' hiolle-hide-logos' : '';
$grid_classes .= !empty($style['center_logo']) ? ' hiolle-center-logo' : '';
$grid_classes .= !empty($style['center_name']) ? ' hiolle-center-name' : '';
$grid_classes .= !empty($style['center_metrics']) ? ' hiolle-center-metrics' : '';
foreach ($data['cards'] as $card) {
    $os = $card['os'];
    if ($os === 'windows') {
        $logo = $tag('span', 'hiolle-windows-logo', [
            $tag('i', 'hiolle-win-tile'), $tag('i', 'hiolle-win-tile'),
            $tag('i', 'hiolle-win-tile'), $tag('i', 'hiolle-win-tile')
        ]);
        $os_name = 'Windows';
    }
    elseif ($os === 'linux') {
        $logo = $tag('span', 'hiolle-linux-logo', '🐧');
        $os_name = 'Linux';
    }
    else {
        $logo = $tag('span', 'hiolle-generic-logo', '▣');
        $os_name = 'Système non identifié';
    }

    $overall = $card['agent']['state'];
    $labels = [
        'ok' => 'Normal',
        'warning' => 'Attention',
        'critical' => 'Critique',
        'unknown' => 'À vérifier'
    ];

    $header = $tag('div', 'hiolle-server-header', [
        $logo,
        $tag('div', 'hiolle-server-identity', [
            $tag('div', 'hiolle-server-name', $card['name']),
            $tag('div', 'hiolle-server-os', $os_name)
        ])
    ]);

    $cards[] = $tag('div', 'hiolle-server-card hiolle-border-'.$overall, [
        $header,
        $ring('CPU', $card['cpu']),
        $ring('RAM', $card['ram']),
        $ring('DISK', $card['disk'], $card['disk']['volume'] ?? null)
    ]);
}

if (!$cards) {
    $cards[] = $tag('div', 'hiolle-empty',
        'Sélectionnez un ou plusieurs hôtes dans la configuration du widget. Si vous en avez déjà choisi, vérifiez les droits de lecture.'
    );
}

$grid = $tag('div', $grid_classes, $cards);
$grid->setAttribute('style', '--hiolle-name-size:'.$style['font_size'].'px;--hiolle-windows-tile-size:'.max(3, floor($style['windows_logo_size'] / 2)).'px;--hiolle-linux-logo-size:'.$style['linux_logo_size'].'px;--hiolle-card-height:'.$style['card_height'].'px;--hiolle-metric-size:'.$style['metric_size'].'px;--hiolle-logo-name-gap:'.$style['logo_name_gap'].'px;--hiolle-ping-size:'.$style['ping_size'].'px;--hiolle-ok: #'.$style['ok_color'].';--hiolle-warning: #'.$style['warning_color'].';--hiolle-critical: #'.$style['critical_color'].'');

(new CWidgetView($data))
    ->addItem($grid)
    ->show();
