# Widget HIOLLE — Zabbix 7.4

Extraire le dossier hiolle_server_rings dans le dossier modules du frontend Zabbix. Scanner le répertoire dans Administration / Modules, puis activer le widget et l'ajouter au tableau de bord.

Le point utilise l'item icmpping (ou icmpping[]) de l'hôte : 1 = vert, 0 = rouge. Absence, erreur ou donnée de plus de 10 minutes = gris. Ajouter le modèle ICMP Ping sur les hôtes si nécessaire. Le widget ne crée pas d'items.

CPU utilisé : system.cpu.util ou system.cpu.util[,used], sinon 100 moins system.cpu.util[,idle] ou system.cpu.util[,idle,avg1].
RAM utilisée : vm.memory.util, vm.memory.utilization ou vm.memory.size[pused]. Sinon 100 moins vm.memory.size[pavailable], ou calcul à partir des octets available / total. Les noms d'items ne sont pas utilisés pour deviner les unités.

Hyper-V uniquement : disque = pourcentage occupé du volume le plus rempli parmi vfs.fs.size et vfs.fs.dependent.size, modes pused ou pfree (converti en occupation). Le volume apparaît dans l'infobulle.

Les couleurs des jauges suivent les seuils du widget. Les mesures non prises en charge, périmées ou absentes affichent —. Les problèmes de services ne pilotent pas le point de ping. Limite : 100 hôtes par widget. Droits de lecture Zabbix respectés.
