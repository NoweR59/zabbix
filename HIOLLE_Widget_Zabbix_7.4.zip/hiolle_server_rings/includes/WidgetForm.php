<?php declare(strict_types=1);

namespace Modules\HiolleServerRings\Includes;

use Zabbix\Widgets\CWidgetForm;
use Zabbix\Widgets\CWidgetField;
use Zabbix\Widgets\Fields\CWidgetFieldIntegerBox;
use Zabbix\Widgets\Fields\CWidgetFieldMultiSelectHost;
use Zabbix\Widgets\Fields\CWidgetFieldCheckBox;
use Zabbix\Widgets\Fields\CWidgetFieldColor;

class WidgetForm extends CWidgetForm {
    public function addFields(): self {
        return $this
            ->addField(
                (new CWidgetFieldMultiSelectHost('hostids', _('Serveurs à afficher')))
                    ->setFlags(CWidgetField::FLAG_NOT_EMPTY | CWidgetField::FLAG_LABEL_ASTERISK)
            )
            ->addField((new CWidgetFieldIntegerBox('cpu_warning', _('CPU orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('cpu_critical', _('CPU rouge dès (%)')))->setDefault(95))
            ->addField((new CWidgetFieldIntegerBox('ram_warning', _('RAM orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('ram_critical', _('RAM rouge dès (%)')))->setDefault(90))
            ->addField((new CWidgetFieldIntegerBox('disk_warning', _('DISK orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('disk_critical', _('DISK rouge dès (%)')))->setDefault(90))
            ->addField((new CWidgetFieldIntegerBox('font_size', _('Taille des noms (px)')))->setDefault(9))
            ->addField((new CWidgetFieldIntegerBox('windows_logo_size', _('Taille logo Windows (px)')))->setDefault(13))
            ->addField((new CWidgetFieldIntegerBox('linux_logo_size', _('Taille logo Linux (px)')))->setDefault(13))
            ->addField((new CWidgetFieldIntegerBox('card_height', _('Hauteur des cartes (px)')))->setDefault(36))
            ->addField((new CWidgetFieldIntegerBox('metric_size', _('Taille CPU/RAM/DISK (px)')))->setDefault(22))
            ->addField((new CWidgetFieldIntegerBox('logo_name_gap', _('Espace logo/nom (px)')))->setDefault(2))
            ->addField((new CWidgetFieldIntegerBox('ping_size', _('Épaisseur de la barre Ping (px)')))->setDefault(2))
            ->addField((new CWidgetFieldCheckBox('names_bold', _('Noms en gras')))->setDefault(0))
            ->addField((new CWidgetFieldCheckBox('names_italic', _('Noms en italique')))->setDefault(0))
            ->addField((new CWidgetFieldCheckBox('show_logo', _('Afficher les logos')))->setDefault(1))
            ->addField((new CWidgetFieldCheckBox('center_logo', _('Centrer le logo')))->setDefault(0))
            ->addField((new CWidgetFieldCheckBox('center_name', _('Centrer le texte')))->setDefault(0))
            ->addField((new CWidgetFieldCheckBox('center_metrics', _('Centrer CPU/RAM/DISK')))->setDefault(0))
            ->addField((new CWidgetFieldColor('ok_color', _('Couleur normale / vert')))->setDefault('46CF80'))
            ->addField((new CWidgetFieldColor('warning_color', _('Couleur attention / orange')))->setDefault('FFB742'))
            ->addField((new CWidgetFieldColor('critical_color', _('Couleur critique / rouge')))->setDefault('FF5264'));
    }
}
