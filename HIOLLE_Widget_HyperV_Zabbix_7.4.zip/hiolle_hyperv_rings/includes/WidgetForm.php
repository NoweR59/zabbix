<?php declare(strict_types=1);

namespace Modules\HiolleHyperVRings\Includes;

use Zabbix\Widgets\CWidgetForm;
use Zabbix\Widgets\CWidgetField;
use Zabbix\Widgets\Fields\CWidgetFieldIntegerBox;
use Zabbix\Widgets\Fields\CWidgetFieldMultiSelectHost;

class WidgetForm extends CWidgetForm {
    public function addFields(): self {
        return $this
            ->addField(
                (new CWidgetFieldMultiSelectHost('hostids', _('Serveurs à afficher')))
                    ->setFlags(CWidgetField::FLAG_NOT_EMPTY | CWidgetField::FLAG_LABEL_ASTERISK)
            )
            ->addField((new CWidgetFieldIntegerBox('cpu_warning', _('CPU orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('cpu_critical', _('CPU rouge dès (%)')))->setDefault(95))
            ->addField((new CWidgetFieldIntegerBox('ram_warning', _('RAM orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('ram_critical', _('RAM rouge dès (%)')))->setDefault(90))
            ->addField((new CWidgetFieldIntegerBox('disk_warning', _('DISK orange dès (%)')))->setDefault(80))
            ->addField((new CWidgetFieldIntegerBox('disk_critical', _('DISK rouge dès (%)')))->setDefault(90));
    }
}

