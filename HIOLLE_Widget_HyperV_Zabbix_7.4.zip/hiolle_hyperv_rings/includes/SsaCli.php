<?php declare(strict_types=1);
namespace Modules\HiolleHyperVRings\Includes;
final class SsaCli {
    public static function parse(string $json): ?array {
        $payload = json_decode($json, true);
        if (!is_array($payload) || !isset($payload['output']) || !is_string($payload['output']) || isset($payload['error'])) { return null; }
        $disks = []; $arrays = []; $controller = ''; $slot = ''; $fields = []; $array = null;
        $output = str_replace(['\\r\\n', '\\n', '\\r'], "\n", $payload['output']);
        $flush = static function () use (&$disks, &$slot, &$fields, &$controller): void {
            if ($slot === '') { return; }
            $status = preg_replace('/\s+/', ' ', trim((string) ($fields['Status'] ?? '')));
            $statusKey = strtolower($status);
            $state = str_contains($statusKey, 'failed') ? 'failed'
                : ((str_contains($statusKey, 'predictive') || str_contains($statusKey, 'rebuilding')) ? 'predictive'
                : ((str_contains($statusKey, 'ok') || $statusKey === '') ? 'ok' : 'unknown'));
            $disks[$controller.' / '.$slot] = ['slot'=>$controller.' / '.$slot, 'state'=>$state,
                'model'=>trim(preg_replace('/\s+/', ' ', $fields['Model'] ?? '').' '.($fields['Size'] ?? '')),
                'serial'=>$fields['Serial Number'] ?? '', 'interface'=>$fields['Interface Type'] ?? '',
                'media'=>isset($fields['Rotational Speed']) ? 'HDD' : '',
                'temperature'=>isset($fields['Current Temperature (C)']) ? $fields['Current Temperature (C)'].'C' : '',
                'firmware'=>$fields['Firmware Revision'] ?? '',
                'label'=>'SSACLI : '.($status ?: 'inconnu')];
            $slot = ''; $fields = [];
        };
        $flushArray = static function () use (&$arrays, &$array): void {
            if (is_array($array) && isset($array['name'])) { $arrays[] = $array; }
            $array = null;
        };
        foreach (preg_split('/\R/', $output) as $line) {
            if (preg_match('/^\s+Array:\s+(.+)$/', $line, $m)) { $flush(); $flushArray(); $array = ['name'=>trim($m[1])]; }
            elseif ($array !== null && preg_match('/^\s+(Unused Space|Used Space|Status):\s*(.*)$/', $line, $m)) { $array[strtolower(str_replace(' ', '_', $m[1]))] = trim($m[2]); }
            elseif (preg_match('/^\S.* in Slot (\S+)/', $line, $m)) { $flush(); $flushArray(); $controller = 'Slot '.$m[1]; }
            elseif (preg_match('/^\s+physicaldrive\s+(\S+)(?:\s.*)?$/i', $line, $m)) { $flush(); $slot = $m[1]; }
            elseif ($slot !== '' && preg_match('/^\s+([^:]+):\s*(.*)$/', $line, $m)) { $fields[trim($m[1])] = trim($m[2]); }
        }
        $flush(); $flushArray();
        return $disks ? ['disks'=>array_values($disks), 'summary'=>$arrays] : null;
    }
}
