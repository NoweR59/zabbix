<?php declare(strict_types=1);

/** @var array $data */

(new CWidgetFormView($data))
    ->addField(new CWidgetFieldMultiSelectHostView($data['fields']['hostids']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['cpu_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['cpu_critical']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['ram_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['ram_critical']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['disk_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['disk_critical']))
    ->show();

