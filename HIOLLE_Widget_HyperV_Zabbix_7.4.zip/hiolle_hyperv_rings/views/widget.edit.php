<?php declare(strict_types=1);

/** @var array $data */

(new CWidgetFormView($data))
    ->addField(new CWidgetFieldMultiSelectHostView($data['fields']['hostids']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['cpu_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['cpu_critical']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['ram_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['ram_critical']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['disk_warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['disk_critical']))
    ->addFieldset(
        (new CWidgetFormFieldsetCollapsibleView(_('Apparence')))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['font_size']))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['windows_logo_size']))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['card_height']))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['metric_size']))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['logo_name_gap']))
            ->addField(new CWidgetFieldIntegerBoxView($data['fields']['ping_size']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['names_bold']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['names_italic']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['show_logo']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['center_logo']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['center_name']))
            ->addField(new CWidgetFieldCheckBoxView($data['fields']['center_metrics']))
            ->addField(new CWidgetFieldColorView($data['fields']['ok_color']))
            ->addField(new CWidgetFieldColorView($data['fields']['warning_color']))
            ->addField(new CWidgetFieldColorView($data['fields']['critical_color']))
    )
    ->addJavaScript('jQuery(".color-picker input").colorpicker();')
    ->show();
