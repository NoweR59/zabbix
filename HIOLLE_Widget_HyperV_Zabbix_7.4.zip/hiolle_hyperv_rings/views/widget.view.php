<?php declare(strict_types=1);

/**
 * @var CView $this
 * @var array $data
 *
 * HTML is built with Zabbix CTag classes so host names are escaped.
 */

$tag = static function(string $name, string $class, $children = ''): CTag {
    return (new CTag($name, true, $children))->addClass($class);
};

$ring = static function(string $label, array $metric, ?string $subtitle = null) use ($tag): CTag {
    $value = $metric['value'];
    $level = $metric['level'];
    $percent = $value === null ? 0 : max(0, min(100, (float) $value));
    $label_value = $value === null ? '—' : number_format((float) $value, 0, ',', ' ').'%';

    $face = $tag('div', 'hiolle-hyperv-gauge-inner', [
        $tag('span', 'hiolle-hyperv-gauge-value', $label_value)
    ]);
    $circle = $tag('div', 'hiolle-hyperv-gauge hiolle-hyperv-level-'.$level, $face);
    $circle->setAttribute('style', '--hiolle-hyperv-pct:'.number_format($percent, 2, '.', '').'%');
    $circle->setAttribute('title', $label.': '.$label_value.($subtitle ? ' ('.$subtitle.')' : ''));

    return $tag('div', 'hiolle-hyperv-metric', [
        $circle,
        $tag('div', 'hiolle-hyperv-metric-label', $label)
    ]);
};

$cards = [];
foreach ($data['cards'] as $card) {
    $os = $card['os'];
    if ($os === 'hyperv') {
        $logo = $tag('span', 'hiolle-hyperv-platform-logo', 'H');
        $os_name = 'Hyper-V';
    }
    elseif ($os === 'windows') {
        $logo = $tag('span', 'hiolle-hyperv-windows-logo', [
            $tag('i', 'hiolle-hyperv-win-tile'), $tag('i', 'hiolle-hyperv-win-tile'),
            $tag('i', 'hiolle-hyperv-win-tile'), $tag('i', 'hiolle-hyperv-win-tile')
        ]);
        $os_name = 'Windows';
    }
    elseif ($os === 'linux') {
        $logo = $tag('span', 'hiolle-hyperv-linux-logo', '🐧');
        $os_name = 'Linux';
    }
    else {
        $logo = $tag('span', 'hiolle-hyperv-generic-logo', '▣');
        $os_name = 'Système non identifié';
    }

    $overall = $card['overall'];
    $labels = [
        'ok' => 'Normal',
        'warning' => 'Attention',
        'critical' => 'Critique',
        'unknown' => 'À vérifier'
    ];

    $status = $tag('div', 'hiolle-hyperv-status hiolle-hyperv-level-'.$card['agent']['state'], [
        $tag('span', 'hiolle-hyperv-status-dot'),
        $tag('span', 'hiolle-hyperv-status-text', $card['agent']['label'])
    ]);
    $status->setAttribute('title', $card['agent']['label']);

    $header = $tag('div', 'hiolle-hyperv-server-header', [
        $logo,
        $tag('div', 'hiolle-hyperv-server-identity', [
            $tag('div', 'hiolle-hyperv-server-name', $card['name']),
            $tag('div', 'hiolle-hyperv-server-os', $os_name)
        ])
    ]);

    $cards[] = $tag('div', 'hiolle-hyperv-server-card hiolle-hyperv-border-'.$overall, [
        $header,
        $status,
        $ring('CPU', $card['cpu']),
        $ring('RAM', $card['ram']),
        $ring('DISK', $card['disk'], $card['disk']['volume'] ?? null)
    ]);
}

if (!$cards) {
    $cards[] = $tag('div', 'hiolle-hyperv-empty',
        'Sélectionnez un ou plusieurs hôtes dans la configuration du widget. Si vous en avez déjà choisi, vérifiez les droits de lecture.'
    );
}

$grid = $tag('div', 'hiolle-hyperv-dashboard-grid', $cards);

(new CWidgetView($data))
    ->addItem($grid)
    ->show();

