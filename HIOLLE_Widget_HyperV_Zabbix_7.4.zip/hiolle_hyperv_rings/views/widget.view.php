<?php declare(strict_types=1);

/**
 * @var CView $this
 * @var array $data
 *
 * HTML is built with Zabbix CTag classes so host names are escaped.
 */

$tag = static function(string $name, string $class, $children = ''): CTag {
    return (new CTag($name, true, $children))->addClass($class);
};

$ring = static function(string $label, array $metric, ?string $subtitle = null) use ($tag): CTag {
    $value = $metric['value'];
    $level = $metric['level'];
    $percent = $value === null ? 0 : max(0, min(100, (float) $value));
    $label_value = $value === null ? '—' : number_format((float) $value, 0, ',', ' ').'%';

    $face = $tag('div', 'hiolle-hyperv-gauge-inner', [
        $tag('span', 'hiolle-hyperv-gauge-value', $label_value)
    ]);
    $circle = $tag('div', 'hiolle-hyperv-gauge hiolle-hyperv-level-'.$level, $face);
    $circle->setAttribute('style', '--hiolle-hyperv-pct:'.number_format($percent, 2, '.', '').'%');
    $circle->setAttribute('title', $label.': '.$label_value.($subtitle ? ' ('.$subtitle.')' : ''));

    return $tag('div', 'hiolle-hyperv-metric', [
        $circle,
        $tag('div', 'hiolle-hyperv-metric-label', $label)
    ]);
};

$cards = [];
$style = $data['style'] ?? [
    'font_size' => 9,
    'windows_logo_size' => 13,
    'linux_logo_size' => 13,
    'card_height' => 36,
    'metric_size' => 22,
    'logo_name_gap' => 2,
    'ping_size' => 2,
    'ok_color' => '46CF80',
    'warning_color' => 'FFB742',
    'critical_color' => 'FF5264',
    'names_bold' => false,
    'names_italic' => false,
    'show_logo' => true,
    'center_logo' => false,
    'center_name' => false,
    'center_metrics' => false
];
$grid_classes = 'hiolle-hyperv-dashboard-grid hiolle-hyperv-font-size-'.$style['font_size'];
$grid_classes .= !empty($style['names_bold']) ? ' hiolle-hyperv-names-bold' : '';
$grid_classes .= !empty($style['names_italic']) ? ' hiolle-hyperv-names-italic' : '';
$grid_classes .= empty($style['show_logo']) ? ' hiolle-hyperv-hide-logos' : '';
$grid_classes .= !empty($style['center_logo']) ? ' hiolle-hyperv-center-logo' : '';
$grid_classes .= !empty($style['center_name']) ? ' hiolle-hyperv-center-name' : '';
$grid_classes .= !empty($style['center_metrics']) ? ' hiolle-hyperv-center-metrics' : '';
foreach ($data['cards'] as $card) {
    $logo = $tag('span', 'hiolle-hyperv-platform-logo', 'H');
    $os_name = 'Hyper-V';

    $overall = $card['agent']['state'];
    $labels = [
        'ok' => 'Normal',
        'warning' => 'Attention',
        'critical' => 'Critique',
        'unknown' => 'À vérifier'
    ];

    $header = $tag('div', 'hiolle-hyperv-server-header', [
        $logo,
        $tag('div', 'hiolle-hyperv-server-identity', [
            $tag('div', 'hiolle-hyperv-server-name', $card['name']),
            $tag('div', 'hiolle-hyperv-server-os', $os_name)
        ]),
        $tag('span', 'hiolle-hyperv-raid-caption hiolle-hyperv-raid-'.$card['raid']['state'], [
            $tag('span', 'hiolle-hyperv-raid-dot', ''),
            (!empty($card['raid']['source']) ? $card['raid']['source'] : 'SNMP').' · '.$card['raid']['label']
        ])
    ]);

    $cards[] = $tag('div', 'hiolle-hyperv-server-card hiolle-hyperv-border-'.$overall, [
        $header,
        $ring('CPU', $card['cpu']),
        $ring('RAM', $card['ram']),
        $ring('DISK', $card['disk'], $card['disk']['volume'] ?? null)
    ]);
}

if (!$cards) {
    $cards[] = $tag('div', 'hiolle-hyperv-empty',
        'Sélectionnez un ou plusieurs hôtes dans la configuration du widget. Si vous en avez déjà choisi, vérifiez les droits de lecture.'
    );
}

$grid = $tag('div', $grid_classes, $cards);
$grid->setAttribute('style', '--hiolle-hyperv-name-size:'.$style['font_size'].'px;--hiolle-hyperv-windows-tile-size:'.max(3, floor($style['windows_logo_size'] / 2)).'px;--hiolle-hyperv-linux-logo-size:'.$style['linux_logo_size'].'px;--hiolle-hyperv-card-height:'.$style['card_height'].'px;--hiolle-hyperv-metric-size:'.$style['metric_size'].'px;--hiolle-hyperv-logo-name-gap:'.$style['logo_name_gap'].'px;--hiolle-hyperv-ping-size:'.$style['ping_size'].'px;--hiolle-hyperv-ok: #'.$style['ok_color'].';--hiolle-hyperv-warning: #'.$style['warning_color'].';--hiolle-hyperv-critical: #'.$style['critical_color'].'');

(new CWidgetView($data))
    ->addItem($grid)
    ->show();
