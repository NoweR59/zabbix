<?php declare(strict_types=1);

namespace Modules\HiolleHyperVRings;

use Zabbix\Core\CWidget;

class Widget extends CWidget {
}

