<?php declare(strict_types=1);
namespace Modules\HiolleTemperatures;
class Widget extends \Zabbix\Core\CWidget {}
