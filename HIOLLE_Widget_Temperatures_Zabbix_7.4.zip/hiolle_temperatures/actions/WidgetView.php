<?php declare(strict_types=1);
namespace Modules\HiolleTemperatures\Actions;
class WidgetView extends \CControllerDashboardWidgetView {
    protected function doAction(): void {
        $warning = (int) ($this->fields_values['warning'] ?? 45);
        $critical = max($warning, (int) ($this->fields_values['critical'] ?? 60));
        $ids = array_values(array_filter(array_map('strval', (array) ($this->fields_values['itemid'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
        $rows = [];
        $groupids = array_values(array_filter(array_map('strval', (array) ($this->fields_values['groupids'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
        $templateids = array_values(array_filter(array_map('strval', (array) ($this->fields_values['templateids'] ?? [])), static fn(string $id): bool => ctype_digit($id)));
        if ($ids) {
            $item_params = ['itemids' => $ids, 'output' => ['name', 'lastvalue', 'lastclock', 'value_type', 'status', 'state'], 'selectHosts' => ['host', 'name']];
            if ($groupids) { $item_params['groupids'] = $groupids; }
            if ($templateids) { $item_params['templateids'] = $templateids; }
            foreach (\API::Item()->get($item_params) as $item) {
                $value = null;
                if (in_array((int) $item['value_type'], [0, 3], true) && (int) $item['status'] === 0 && (int) $item['state'] === 0
                        && (int) $item['lastclock'] >= time() - 3600 && is_numeric($item['lastvalue'])) { $value = (float) $item['lastvalue']; }
                $host = $item['hosts'][0] ?? [];
                $host_name = $host['name'] ?? ($host['host'] ?? $item['name']);
                $site_name = trim((string) preg_replace('/^\s*T°\s*[-–—:]?\s*/u', '', $host_name));
                $rows[] = ['name' => 'T° - '.($site_name !== '' ? $site_name : $host_name), 'value' => $value, 'state' => $value === null ? 'unknown' : ($value >= $critical ? 'critical' : ($value >= $warning ? 'warning' : 'ok'))];
            }
        }
        elseif (($this->fields_values['demo'] ?? 1)) {
            $demo_value = (float) ($this->fields_values['demo_value'] ?? 25);
            $rows[] = ['name' => 'Température simulée', 'value' => $demo_value, 'state' => $demo_value >= $critical ? 'critical' : ($demo_value >= $warning ? 'warning' : 'ok')];
        }
        $color = static function ($value, string $fallback): string {
            $value = preg_replace('/[^0-9A-Fa-f]/', '', (string) $value);
            return '#'.(strlen($value) === 6 ? $value : $fallback);
        };
        $colors = ['ok' => $color($this->fields_values['ok_color'] ?? '', '46CF80'), 'warning' => $color($this->fields_values['warning_color'] ?? '', 'FFB742'), 'critical' => $color($this->fields_values['critical_color'] ?? '', 'FF5264'), 'unknown' => '#93A7B7'];
        $this->setResponse(new \CControllerResponseData([
            'name' => $this->getInput('name', $this->widget->getName()),
            'rows' => $rows, 'colors' => $colors,
            'size' => max(12, min(160, (int) ($this->fields_values['value_size'] ?? 64))),
            'name_size' => max(8, min(40, (int) ($this->fields_values['name_size'] ?? 12))),
            'name_bold' => !empty($this->fields_values['name_bold']),
            'center_name' => !empty($this->fields_values['center_name'])
        ]));
    }
}
