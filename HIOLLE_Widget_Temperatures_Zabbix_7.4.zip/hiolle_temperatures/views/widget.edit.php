<?php declare(strict_types=1);
require_once dirname(__DIR__).'/includes/TemplateField.php';
(new CWidgetFormView($data))
    ->addField(new CWidgetFieldMultiSelectGroupView($data['fields']['groupids']))
    ->addField(new HiolleTemperatureTemplateView($data['fields']['templateids']))
    ->addField(new CWidgetFieldMultiSelectItemView($data['fields']['itemid']))
    ->addField(new CWidgetFieldCheckBoxView($data['fields']['demo']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['demo_value']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['warning']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['critical']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['value_size']))
    ->addField(new CWidgetFieldIntegerBoxView($data['fields']['name_size']))
    ->addField(new CWidgetFieldCheckBoxView($data['fields']['name_bold']))
    ->addField(new CWidgetFieldCheckBoxView($data['fields']['center_name']))
    ->addField(new CWidgetFieldColorView($data['fields']['ok_color']))
    ->addField(new CWidgetFieldColorView($data['fields']['warning_color']))
    ->addField(new CWidgetFieldColorView($data['fields']['critical_color']))
    ->show();
