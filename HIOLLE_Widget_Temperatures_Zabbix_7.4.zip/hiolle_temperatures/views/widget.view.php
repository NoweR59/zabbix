<?php declare(strict_types=1);
$body = (new CDiv())->addClass('hiolle-temp-list');
foreach ($data['rows'] as $row) {
    $value = $row['value'] === null ? '—' : number_format($row['value'], 0, ',', ' ').'°';
    $item = (new CDiv([
        (new CDiv($row['name']))->addClass('hiolle-temp-name'.($data['name_bold'] ? ' hiolle-temp-name-bold' : '')),
        (new CDiv($value))->addClass('hiolle-temp-single hiolle-temp-'.$row['state'])
    ]))->addClass('hiolle-temp-item'.($data['center_name'] ? ' hiolle-temp-center-name' : ''))
        ->setAttribute('style', '--temperature-size:'.$data['size'].'px;--temperature-name-size:'.$data['name_size'].'px;--temperature-color:'.$data['colors'][$row['state']].';');
    $body->addItem($item);
}
(new CWidgetView($data))->addItem($body)->show();
