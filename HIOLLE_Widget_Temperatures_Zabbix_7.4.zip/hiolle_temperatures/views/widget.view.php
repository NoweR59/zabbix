<?php declare(strict_types=1);
$body = (new CDiv())->addClass('hiolle-temp-list');
foreach ($data['rows'] as $row) {
    $value = $row['value'] === null ? '—' : number_format($row['value'], 0, ',', ' ').'°';
    $body->addItem((new CDiv([
        (new CDiv($row['name']))->addClass('hiolle-temp-name'),
        (new CDiv($value))->addClass('hiolle-temp-single hiolle-temp-'.$row['state'])
    ]))->addClass('hiolle-temp-item')->setAttribute('style', '--temperature-size:'.$data['size'].'px;--temperature-color:'.$data['colors'][$row['state']].';'));
}
(new CWidgetView($data))->addItem($body)->show();
