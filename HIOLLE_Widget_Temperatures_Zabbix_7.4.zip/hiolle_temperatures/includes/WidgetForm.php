<?php declare(strict_types=1);
namespace Modules\HiolleTemperatures\Includes;
require_once __DIR__.'/TemplateField.php';
use Zabbix\Widgets\Fields\CWidgetFieldIntegerBox;
use Zabbix\Widgets\Fields\CWidgetFieldColor;
use Zabbix\Widgets\Fields\CWidgetFieldMultiSelectGroup;
use Modules\HiolleTemperatures\Includes\CWidgetFieldMultiSelectTemplate;
class WidgetForm extends \Zabbix\Widgets\CWidgetForm {
    public function addFields(): self {
        return $this
            ->addField(new CWidgetFieldMultiSelectGroup('groupids', _('Groupes d’hôtes')))
            ->addField(new CWidgetFieldMultiSelectTemplate('templateids', _('Modèles d’éléments')))
            ->addField(new \Zabbix\Widgets\Fields\CWidgetFieldMultiSelectItem('itemid', _('Éléments température')))
            ->addField((new \Zabbix\Widgets\Fields\CWidgetFieldCheckBox('demo', _('Simulation si aucun élément sélectionné')))->setDefault(1))
            ->addField((new CWidgetFieldIntegerBox('demo_value', _('Température simulée (°C)'), -100, 300))->setDefault(25))
            ->addField((new CWidgetFieldIntegerBox('warning', _('Orange dès (°C)'), 0, 150))->setDefault(45))
            ->addField((new CWidgetFieldIntegerBox('critical', _('Rouge dès (°C)'), 0, 150))->setDefault(60))
            ->addField((new CWidgetFieldIntegerBox('value_size', _('Taille des chiffres (px)'), 12, 160))->setDefault(64))
            ->addField((new CWidgetFieldColor('ok_color', _('Couleur normale')))->setDefault('46CF80'))
            ->addField((new CWidgetFieldColor('warning_color', _('Couleur attention')))->setDefault('FFB742'))
            ->addField((new CWidgetFieldColor('critical_color', _('Couleur critique')))->setDefault('FF5264'));
    }
}
