<?php declare(strict_types=1);
namespace Modules\HiolleTemperatures\Includes {
    class CWidgetFieldMultiSelectTemplate extends \Zabbix\Widgets\Fields\CWidgetFieldMultiSelect {
        public const DEFAULT_VIEW = \HiolleTemperatureTemplateView::class;
        public function __construct(string $name, ?string $label = null) {
            parent::__construct($name, $label);
            $this->inaccessible_caption = _('Modèle inaccessible');
            $this->setSaveType(ZBX_WIDGET_FIELD_TYPE_HOST);
        }
    }
}
namespace {
    class HiolleTemperatureTemplateView extends \CWidgetFieldMultiSelectView {
        public function __construct(\Modules\HiolleTemperatures\Includes\CWidgetFieldMultiSelectTemplate $field) { parent::__construct($field); }
        protected function getObjectName(): string { return 'template'; }
        protected function getObjectLabels(): array { return ['object' => _('Modèle'), 'objects' => _('Modèles')]; }
        protected function getPopupParameters(): array { return $this->popup_parameters + ['srctbl' => 'templates', 'srcfld1' => 'templateid']; }
    }
}
